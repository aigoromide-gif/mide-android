# mide — Offline Android Photo Editor

Mide is a real Android photo editor starter project designed around a clean blue interface. The current first build includes:

- Offline photo selection from the device
- Brightness, contrast, saturation, temperature and tint controls
- Mide Blue, Vivid, Cool and Moody presets
- Before-save live preview
- JPEG export to `Pictures/Mide`
- No server or account required for editing

## Open and build

1. Install Android Studio.
2. Open the `Mide` folder.
3. Let Android Studio sync Gradle dependencies.
4. Run the app on an Android phone or emulator.
5. Use **Start Editing** to select a local photo.
6. Edit and press **Save**.

The UI uses Jetpack Compose. Android's official documentation recommends Compose for modern native Android UI development. The app uses the Android system document picker, so the selected photo can be processed locally without an internet connection.

## Next development stages

- Non-destructive edit history and undo/redo
- Crop/rotate/straighten
- Curves and HSL color controls
- More Mide color presets
- Batch editing
- Export quality/size options
- App icon and splash screen
- Signed release APK and Google Play AAB
