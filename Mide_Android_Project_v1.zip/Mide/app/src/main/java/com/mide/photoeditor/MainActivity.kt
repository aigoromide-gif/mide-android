package com.mide.photoeditor

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.ColorMatrix as AndroidColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FilterVintage
import androidx.compose.material.icons.filled.PhotoFilter
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.LaunchedEffect

private val Navy = Color(0xFF06152F)
private val Blue = Color(0xFF1688FF)
private val CardBlue = Color(0xFF0B2A55)
private val SoftBlue = Color(0xFF8FD1FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MideApp() }
    }
}

@Composable
fun MideApp() {
    var started by remember { mutableStateOf(false) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showEditor by remember { mutableStateOf(false) }

    if (!started) {
        WelcomeScreen(onStart = { started = true })
        return
    }

    if (showEditor && bitmap != null) {
        EditorScreen(bitmap = bitmap!!, onBack = { showEditor = false })
        return
    }

    HomeScreen(
        onPicked = { bmp -> bitmap = bmp; showEditor = true }
    )
}

@Composable
private fun WelcomeScreen(onStart: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("mide", fontSize = 58.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Edit more. Create better.", color = SoftBlue, fontSize = 17.sp)
                Spacer(Modifier.height(70.dp))
                Button(
                    onClick = onStart,
                    colors = ButtonDefaults.buttonColors(containerColor = Blue),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().height(58.dp)
                ) { Text("Get Started", fontSize = 17.sp) }
                Spacer(Modifier.height(18.dp))
                Text("Offline photo editing", color = Color(0xFF9FB1CC), fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun HomeScreen(
    onPicked: (Bitmap) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val bmp = BitmapFactory.decodeStream(context.contentResolver.openInputStream(uri))
            if (bmp != null) onPicked(bmp)
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
            Spacer(Modifier.height(24.dp))
            Text("mide", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text("Welcome back", color = SoftBlue, fontSize = 15.sp)
            Spacer(Modifier.height(24.dp))

            Button(
                onClick = { picker.launch("image/*") },
                colors = ButtonDefaults.buttonColors(containerColor = Blue),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().height(82.dp)
            ) {
                Icon(Icons.Default.AddPhotoAlternate, null)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Start Editing", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Choose a photo from your phone", fontSize = 12.sp)
                }
            }

            Spacer(Modifier.height(28.dp))
            Text("Quick Tools", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ToolCard("Adjust", Icons.Default.Tune)
                ToolCard("Filters", Icons.Default.FilterVintage)
                ToolCard("Effects", Icons.Default.AutoAwesome)
            }
            Spacer(Modifier.height(24.dp))
            Text("Made for offline editing", color = Color(0xFF9FB1CC), fontSize = 13.sp)
        }
    }
}

@Composable
private fun ToolCard(title: String, icon: ImageVector) {
    Card(
        modifier = Modifier.weight(1f).height(110.dp),
        colors = CardDefaults.cardColors(containerColor = CardBlue),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = SoftBlue, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(8.dp))
            Text(title, color = Color.White, fontSize = 13.sp)
        }
    }
}

private data class Adjustment(val name: String, val range: ClosedFloatingPointRange<Float>, val value: Float)

@Composable
private fun EditorScreen(bitmap: Bitmap, onBack: () -> Unit) {
    var brightness by remember { mutableStateOf(0f) }
    var contrast by remember { mutableStateOf(1f) }
    var saturation by remember { mutableStateOf(1f) }
    var temperature by remember { mutableStateOf(0f) }
    var tint by remember { mutableStateOf(0f) }
    var active by remember { mutableStateOf("Adjust") }
    var message by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current

    val matrix = remember(brightness, contrast, saturation, temperature, tint) {
        buildMatrix(brightness, contrast, saturation, temperature, tint)
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
                Text("Edit", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Button(
                    onClick = {
                        val saved = saveEditedBitmap(context, bitmap, matrix)
                        message = if (saved) "Saved to Pictures/Mide" else "Could not save photo"
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Blue),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("Save") }
            }

            Box(
                modifier = Modifier.fillMaxWidth().height(330.dp).padding(horizontal = 12.dp).clip(RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Photo being edited",
                    contentScale = ContentScale.Fit,
                    colorFilter = androidx.compose.ui.graphics.ColorFilter.colorMatrix(matrix),
                    modifier = Modifier.fillMaxSize()
                )
            }

            Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Adjust", "Filters", "Tools").forEach { tab ->
                    Button(
                        onClick = { active = tab },
                        colors = ButtonDefaults.buttonColors(containerColor = if (active == tab) Blue else CardBlue),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text(tab, fontSize = 12.sp) }
                }
            }

            if (active == "Adjust") {
                Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
                    AdjustmentSlider("Brightness", brightness, -1f..1f) { brightness = it }
                    AdjustmentSlider("Contrast", contrast, 0.5f..1.8f) { contrast = it }
                    AdjustmentSlider("Saturation", saturation, 0f..2f) { saturation = it }
                    AdjustmentSlider("Temperature", temperature, -1f..1f) { temperature = it }
                    AdjustmentSlider("Tint", tint, -1f..1f) { tint = it }
                }
            } else if (active == "Filters") {
                FilterRow { preset ->
                    when (preset) {
                        "Original" -> { brightness = 0f; contrast = 1f; saturation = 1f; temperature = 0f; tint = 0f }
                        "Mide Blue" -> { brightness = 0.03f; contrast = 1.12f; saturation = 1.12f; temperature = -0.35f; tint = 0f }
                        "Vivid" -> { brightness = 0.04f; contrast = 1.15f; saturation = 1.45f; temperature = 0f; tint = 0f }
                        "Cool" -> { brightness = 0f; contrast = 1.08f; saturation = 1.05f; temperature = -0.55f; tint = 0f }
                        "Moody" -> { brightness = -0.08f; contrast = 1.28f; saturation = 0.9f; temperature = -0.1f; tint = 0f }
                    }
                }
            } else {
                Text("Tools", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(18.dp))
                Text("Crop and advanced tools are next in the Mide roadmap.", color = Color(0xFF9FB1CC), modifier = Modifier.padding(horizontal = 18.dp))
            }

            if (message.isNotEmpty()) {
                Text(message, color = SoftBlue, modifier = Modifier.padding(16.dp), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun AdjustmentSlider(name: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(modifier = Modifier.padding(vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(name, color = Color.White, fontSize = 14.sp)
            Text(String.format("%.2f", value), color = SoftBlue, fontSize = 12.sp)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun FilterRow(onPreset: (String) -> Unit) {
    val presets = listOf("Original", "Mide Blue", "Vivid", "Cool", "Moody")
    LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(presets) { preset ->
            Button(
                onClick = { onPreset(preset) },
                colors = ButtonDefaults.buttonColors(containerColor = CardBlue),
                shape = RoundedCornerShape(14.dp)
            ) { Text(preset, fontSize = 12.sp) }
        }
    }
}

private fun buildMatrix(brightness: Float, contrast: Float, saturation: Float, temperature: Float, tint: Float): ColorMatrix {
    val c = contrast
    val b = brightness * 255f
    val sat = saturation
    val rLum = 0.213f
    val gLum = 0.715f
    val bLum = 0.072f
    val sr = (1 - sat) * rLum
    val sg = (1 - sat) * gLum
    val sb = (1 - sat) * bLum
    val warm = temperature * 32f
    val greenTint = tint * 18f
    val off = 128f * (1f - c) + b
    return ColorMatrix(floatArrayOf(
        c * (sr + sat) , c * sg, c * sb, 0f, off + warm,
        c * sr, c * (sg + sat), c * sb, 0f, off + greenTint,
        c * sr, c * sg, c * (sb + sat), 0f, off - warm,
        0f, 0f, 0f, 1f, 0f
    ))
}

private fun saveEditedBitmap(context: android.content.Context, source: Bitmap, matrix: ColorMatrix): Boolean {
    return try {
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val androidMatrix = AndroidColorMatrix(matrix.values)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = ColorMatrixColorFilter(androidMatrix) }
        canvas.drawBitmap(source, 0f, 0f, paint)

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "Mide_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Mide")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        resolver.openOutputStream(uri).use { stream ->
            if (stream == null) return false
            output.compress(Bitmap.CompressFormat.JPEG, 95, stream)
        }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        true
    } catch (_: Exception) {
        false
    }
}
