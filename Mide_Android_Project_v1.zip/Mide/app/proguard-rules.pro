# Mide release rules
